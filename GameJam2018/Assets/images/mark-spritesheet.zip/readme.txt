Mark [Adventure Game] sprite
by Marco Giorgini - marcogiorgini.com

This spritesheet was created by me (and not used) for #adventurejam 2015. My idea was to do something that looked like Maniac Mansion sprites - but with a different animation style.

I release it, the 18th Aprile 2015, with a CC0 license. I mean - do whatever you want with it - no credits needed (even if they'll be appreciated)

Hope you like it, and hope you can use it for your games

Regards
 M

Frame informations [24x70 pixel]

1 - front
2 - frontright
3 - right
4 - back
5 - left
6 - frontleft
7-10 - walk down
11-15 - walk right
16-19 - walk up
20-24 - walk left